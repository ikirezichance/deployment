let editingId = null;

// Handle form submission
document.getElementById("studentForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const regno = document.getElementById("regno").value.trim();
  const dob = document.getElementById("dob").value;

  if (!regno || !dob) return alert("Please fill all fields");

  let students = getStudents();

  if (editingId) {
    // Update existing
    students = students.map((student) =>
      student.id === editingId ? { id: editingId, regno, dob } : student
    );
    editingId = null;
    document.querySelector("button[type='submit']").textContent = "Add Student";
  } else {
    // Add new
    const newStudent = { id: Date.now(), regno, dob };
    students.push(newStudent);
  }

  saveStudents(students);
  e.target.reset();
  displayStudents();
});

// Load students from localStorage
function getStudents() {
  return JSON.parse(localStorage.getItem("students")) || [];
}

// Save to localStorage
function saveStudents(data) {
  localStorage.setItem("students", JSON.stringify(data));
}

// Delete student
function deleteStudent(id) {
  const students = getStudents().filter((s) => s.id !== id);
  saveStudents(students);
  displayStudents();
}

// Edit student
function editStudent(id) {
  const student = getStudents().find((s) => s.id === id);
  document.getElementById("regno").value = student.regno;
  document.getElementById("dob").value = student.dob;
  editingId = id;
  document.querySelector("button[type='submit']").textContent = "Update Student";
}

// Display table
function displayStudents() {
  const students = getStudents();
  const tbody = document.getElementById("studentTableBody");
  tbody.innerHTML = "";

  students.forEach((student) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${student.regno}</td>
      <td>${student.dob}</td>
      <td>
        <button onclick="editStudent(${student.id})">Edit</button>
        <button onclick="deleteStudent(${student.id})">Delete</button>
      </td>
    `;

    tbody.appendChild(row);
  });
}

displayStudents();
